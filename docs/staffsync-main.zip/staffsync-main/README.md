# staffsync
A website for the staff in a institute
